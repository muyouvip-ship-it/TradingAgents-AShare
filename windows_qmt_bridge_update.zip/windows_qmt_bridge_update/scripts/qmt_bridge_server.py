from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field


app = FastAPI(title="QMT Bridge Server", version="1.0.0")
_SECURITY_NAME_CACHE: dict[str, str] = {}
_HISTORY_JOBS: dict[str, dict[str, Any]] = {}
_HISTORY_JOBS_LOCK = threading.Lock()


def _log(message: str) -> None:
    print(f"[qmt-bridge] {message}", flush=True)


class OrderSubmitRequest(BaseModel):
    account_id: str = Field(..., min_length=1)
    account_type: str = Field(default="STOCK", min_length=1)
    account_key: str | None = None
    symbol: str = Field(..., min_length=1)
    side: str = Field(..., min_length=1)
    quantity: int = Field(..., gt=0)
    price: float | None = Field(default=None, gt=0)
    price_type: str = Field(default="limit", min_length=1)
    strategy_name: str | None = None
    order_remark: str | None = None


class HistoryMinuteSyncRequest(BaseModel):
    period: str = Field(default="1m", min_length=1)
    start_date: str = Field(..., min_length=10)
    end_date: str = Field(..., min_length=10)
    sector: str = Field(default="all_a", min_length=1)
    symbols: list[str] = Field(default_factory=list)
    output_root: str | None = None
    file_format: str = Field(default="parquet", pattern="^(parquet|csv)$")
    import_db: bool = True
    database_url: str | None = None
    force: bool = False
    window_days: int = Field(default=365, ge=1)
    retry_times: int = Field(default=2, ge=0)
    retry_sleep: float = Field(default=1.0, ge=0)


def _bridge_token() -> str:
    return str(os.getenv("QMT_BRIDGE_TOKEN") or "").strip()


def _require_token(authorization: str | None) -> None:
    expected = _bridge_token()
    if not expected:
        return
    token = str(authorization or "").removeprefix("Bearer ").strip()
    if token != expected:
        raise HTTPException(status_code=401, detail="bridge token invalid")


def _bridge_role() -> str:
    role = str(os.getenv("QMT_BRIDGE_ROLE") or "").strip().lower()
    if role:
        return role
    return "live" if str(os.getenv("QMT_BRIDGE_PORT") or "").strip() == "8711" else "paper"


def _bridge_trading_allowed() -> bool:
    raw = os.getenv("QMT_BRIDGE_ALLOW_TRADING")
    if raw is not None:
        return str(raw).strip().lower() in {"1", "true", "yes", "on"}
    return _bridge_role() == "paper"


def _require_trading_allowed(action: str, account_key: str | None) -> None:
    role = _bridge_role()
    if _bridge_trading_allowed() and role == "paper" and str(account_key or "").strip().lower() != "live_real":
        return
    _log(f"reject trading action={action} role={role} account_key={account_key} allow={_bridge_trading_allowed()}")
    raise HTTPException(status_code=403, detail="QMT bridge is readonly for this account; trading is disabled")


def _symbol_for_xt(value: str) -> str:
    symbol = _normalize_symbol(value)
    if not symbol:
        raise HTTPException(status_code=400, detail="symbol is required")
    return symbol


def _normalize_symbol(value: Any) -> str:
    symbol = str(value or "").strip().upper()
    if not symbol:
        return ""
    if "." in symbol:
        return symbol
    if len(symbol) == 6:
        if symbol.startswith("6"):
            return f"{symbol}.SH"
        if symbol.startswith(("0", "3")):
            return f"{symbol}.SZ"
        if symbol.startswith(("4", "8")):
            return f"{symbol}.BJ"
    return symbol


def _looks_like_symbol(value: Any) -> bool:
    text = str(value or "").strip().upper()
    return (len(text) == 6 and text.isdigit()) or (
        len(text) == 9 and text[:6].isdigit() and text[6:] in (".SH", ".SZ", ".BJ")
    )


def _query_security_name(symbol: str) -> str:
    normalized = _normalize_symbol(symbol)
    if not normalized:
        return ""
    if normalized in _SECURITY_NAME_CACHE:
        return _SECURITY_NAME_CACHE[normalized]
    name = ""
    try:
        from xtquant import xtdata

        detail = xtdata.get_instrument_detail(normalized) or {}
        if isinstance(detail, dict):
            for key in ("InstrumentName", "instrument_name", "StockName", "stock_name", "name"):
                value = str(detail.get(key) or "").strip()
                if value and not _looks_like_symbol(value):
                    name = value
                    break
    except Exception as exc:
        _log(f"query security name failed symbol={normalized}: {exc}")
    if name:
        _SECURITY_NAME_CACHE[normalized] = name
    return name


def _resolve_payload_symbol(payload: dict[str, Any]) -> str:
    return _normalize_symbol(
        payload.get("stockCode")
        or payload.get("stock_code")
        or payload.get("symbol")
        or payload.get("m_strStockCode")
    )


def _resolve_payload_name(payload: dict[str, Any], symbol: str) -> str:
    for key in (
        "stockName",
        "stock_name",
        "security_name",
        "name",
        "instrument_name",
        "InstrumentName",
        "m_strStockName",
        "m_strInstrumentName",
    ):
        value = str(payload.get(key) or "").strip()
        if value and not _looks_like_symbol(value):
            return value
    return _query_security_name(symbol) or symbol


def _enrich_security_names(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    enriched: list[dict[str, Any]] = []
    for item in items:
        payload = dict(item)
        symbol = _resolve_payload_symbol(payload)
        if symbol:
            payload.setdefault("symbol", symbol)
            payload.setdefault("stock_code", symbol)
            payload["security_name"] = _resolve_payload_name(payload, symbol)
            payload.setdefault("stockName", payload["security_name"])
        enriched.append(payload)
    return enriched


def _resolve_order_params(side: str, price_type: str, symbol: str) -> tuple[int, int]:
    try:
        from xtquant import xtconstant
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"xtconstant unavailable: {exc}") from exc

    side_key = str(side or "").strip().lower()
    if side_key in {"buy", "long_buy", "b"}:
        order_type = getattr(xtconstant, "STOCK_BUY", 23)
    elif side_key in {"sell", "long_sell", "s"}:
        order_type = getattr(xtconstant, "STOCK_SELL", 24)
    else:
        raise HTTPException(status_code=400, detail=f"unsupported side: {side}")

    price_key = str(price_type or "limit").strip().lower()
    exchange = symbol.split(".")[-1] if "." in symbol else ""
    price_type_map = {
        "limit": getattr(xtconstant, "FIX_PRICE", 11),
        "latest": getattr(xtconstant, "FIX_PRICE", 11),
        "opponent": getattr(xtconstant, "MARKET_PEER_PRICE_FIRST", getattr(xtconstant, "FIX_PRICE", 11)),
        "self_best": getattr(xtconstant, "MARKET_MINE_PRICE_FIRST", getattr(xtconstant, "FIX_PRICE", 11)),
        "best5_cancel": getattr(
            xtconstant,
            "MARKET_SH_CONVERT_5_CANCEL" if exchange == "SH" else "MARKET_SZ_CONVERT_5_CANCEL",
            getattr(xtconstant, "FIX_PRICE", 11),
        ),
    }
    if price_key not in price_type_map:
        raise HTTPException(status_code=400, detail=f"unsupported price_type: {price_type}")
    return order_type, price_type_map[price_key]


def _query_latest_price(symbol: str) -> float:
    normalized = _normalize_symbol(symbol)

    def _extract_price(payload: Any) -> float | None:
        if payload is None:
            return None
        if isinstance(payload, (int, float)):
            price = float(payload)
            return price if price > 0 else None
        if isinstance(payload, dict):
            for key in (
                "lastPrice",
                "last_price",
                "latest",
                "price",
                "last",
                "close",
                "m_dLastPrice",
                "m_dClose",
            ):
                try:
                    price = float(payload.get(key))
                except Exception:
                    continue
                if price > 0:
                    return price
            for value in payload.values():
                found = _extract_price(value)
                if found:
                    return found
        if isinstance(payload, (list, tuple)):
            for value in payload:
                found = _extract_price(value)
                if found:
                    return found
        for attr in ("iloc",):
            if hasattr(payload, attr):
                try:
                    found = _extract_price(payload.iloc[-1])
                    if found:
                        return found
                except Exception:
                    pass
        return None

    try:
        from xtquant import xtdata

        for stock in (normalized, symbol):
            ticks = xtdata.get_full_tick([stock]) or {}
            price = _extract_price(ticks.get(stock) if isinstance(ticks, dict) else ticks)
            if price:
                return price
        get_market_data = getattr(xtdata, "get_market_data", None)
        if callable(get_market_data):
            data = get_market_data(field_list=["close"], stock_list=[normalized], period="1d", count=1)
            price = _extract_price(data)
            if price:
                return price
    except Exception as exc:
        _log(f"query latest price failed symbol={normalized}: {exc}")
    raise HTTPException(status_code=400, detail=f"latest price unavailable: {normalized}")


def _create_trader(account_id: str, account_type: str):
    try:
        from xtquant.xttrader import XtQuantTrader, XtQuantTraderCallback
        from xtquant.xttype import StockAccount
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"xtquant unavailable: {exc}") from exc

    userdata_path = str(os.getenv("QMT_USERDATA_PATH") or "").strip()
    if not userdata_path:
        raise HTTPException(status_code=400, detail="QMT_USERDATA_PATH is required")

    session_id = int(time.time() * 1000) % 100000000
    _log(f"create trader session={session_id} account_id={account_id} account_type={account_type}")
    trader = XtQuantTrader(userdata_path, session_id)
    account = StockAccount(account_id, account_type)

    class _Callback(XtQuantTraderCallback):
        def on_disconnected(self):
            _log("xttrader disconnected")

        def on_account_status(self, status):
            status_value = getattr(status, "status", None)
            _log(f"account status update: {status_value}")

    register_callback = getattr(trader, "register_callback", None)
    if callable(register_callback):
        _log("register callback")
        register_callback(_Callback())

    start = getattr(trader, "start", None)
    if callable(start):
        _log("start trader thread")
        start()
    _log("connect trader")
    connect_result = getattr(trader, "connect")()
    _log(f"connect result={connect_result}")
    if connect_result not in (0, None):
        raise HTTPException(status_code=502, detail=f"connect failed: {connect_result}")
    subscribe = getattr(trader, "subscribe", None)
    if callable(subscribe):
        _log("subscribe account")
        subscribe_result = subscribe(account)
        _log(f"subscribe result={subscribe_result}")
    return trader, account


def _stop_trader(trader: Any) -> None:
    stop = getattr(trader, "stop", None)
    if callable(stop):
        try:
            _log("stop trader")
            stop()
        except Exception:
            pass


def _query_snapshot(account_id: str, account_type: str) -> dict[str, Any]:
    trader, account = _create_trader(account_id, account_type)

    positions = None
    asset = None
    orders = None
    trades = None
    try:
        _log("query stock asset")
        asset = trader.query_stock_asset(account)
        _log("query stock positions")
        if positions in (None, []):
            positions = trader.query_stock_positions(account)
        _log("query stock orders")
        query_stock_orders = getattr(trader, "query_stock_orders", None)
        if callable(query_stock_orders):
            orders = query_stock_orders(account)
        _log("query stock trades")
        query_stock_trades = getattr(trader, "query_stock_trades", None)
        if callable(query_stock_trades):
            trades = query_stock_trades(account)
    finally:
        _stop_trader(trader)

    def normalize(item: Any) -> dict[str, Any]:
        if isinstance(item, dict):
            return item
        data: dict[str, Any] = {}
        for key in dir(item):
            if key.startswith("_"):
                continue
            value = getattr(item, key, None)
            if callable(value):
                continue
            if isinstance(value, (str, int, float, bool, list, dict)) or value is None:
                data[key] = value
        return data

    normalized_positions = [normalize(item) for item in (positions or [])]
    normalized_orders = [normalize(item) for item in (orders or [])]
    normalized_trades = [normalize(item) for item in (trades or [])]

    return {
        "asset": normalize(asset),
        "positions": _enrich_security_names(normalized_positions),
        "orders": _enrich_security_names(normalized_orders),
        "trades": _enrich_security_names(normalized_trades),
    }


def _submit_order(request: OrderSubmitRequest) -> dict[str, Any]:
    symbol = _symbol_for_xt(request.symbol)
    order_type, price_mode = _resolve_order_params(request.side, request.price_type, symbol)
    price_key = str(request.price_type or "limit").strip().lower()
    order_price = request.price
    if price_key == "latest" and order_price is None:
        try:
            order_price = _query_latest_price(symbol)
            _log(f"resolved latest price symbol={symbol} price={order_price}")
        except HTTPException as exc:
            order_type, price_mode = _resolve_order_params(request.side, "opponent", symbol)
            order_price = 0.0
            _log(f"latest price unavailable, fallback to opponent price symbol={symbol} detail={exc.detail}")
    if price_key == "limit" and order_price is None:
        raise HTTPException(status_code=400, detail="limit order requires price")

    trader, account = _create_trader(request.account_id, request.account_type)
    try:
        order_stock = getattr(trader, "order_stock", None)
        if not callable(order_stock):
            raise HTTPException(status_code=500, detail="xttrader.order_stock unavailable")
        _log(
            f"submit order symbol={symbol} side={request.side} qty={request.quantity} price={order_price} price_type={request.price_type} price_mode={price_mode}"
        )
        holder: dict[str, Any] = {}

        def _call_order_stock() -> None:
            try:
                holder["result"] = order_stock(
                    account,
                    symbol,
                    order_type,
                    int(request.quantity),
                    price_mode,
                    float(order_price or 0.0),
                    str(request.strategy_name or "CodexQmtBridge"),
                    str(request.order_remark or ""),
                )
            except Exception as exc:
                holder["error"] = exc

        worker = threading.Thread(target=_call_order_stock, daemon=True)
        worker.start()
        worker.join(float(os.getenv("QMT_ORDER_TIMEOUT_SECONDS") or "12"))
        if worker.is_alive():
            _log(f"submit order timeout symbol={symbol} qty={request.quantity} price_type={request.price_type}")
            raise HTTPException(status_code=504, detail="xttrader.order_stock timeout; please query orders/trades to confirm")
        if holder.get("error") is not None:
            raise holder["error"]
        result = holder.get("result")
        _log(f"submit order result={result}")
        return {
            "success": True,
            "order_id": str(result),
            "result": result,
            "request": {**request.model_dump(), "resolved_price": order_price, "resolved_price_mode": price_mode},
        }
    finally:
        _stop_trader(trader)


def _cancel_order(account_id: str, account_type: str, order_id: str) -> dict[str, Any]:
    trader, account = _create_trader(account_id, account_type)
    try:
        cancel_order_stock = getattr(trader, "cancel_order_stock", None)
        if not callable(cancel_order_stock):
            raise HTTPException(status_code=500, detail="xttrader.cancel_order_stock unavailable")
        cancel_arg: Any = int(order_id) if str(order_id).isdigit() else order_id
        _log(f"cancel order order_id={order_id}")
        result = cancel_order_stock(account, cancel_arg)
        _log(f"cancel order result={result}")
        return {
            "success": True,
            "order_id": str(order_id),
            "result": result,
        }
    finally:
        _stop_trader(trader)


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _history_script_path() -> Path:
    return Path(__file__).resolve().parent / "qmt_minute_history_sync.py"


def _history_output_root(request: HistoryMinuteSyncRequest) -> str:
    return str(request.output_root or os.getenv("QMT_MINUTE_OUTPUT_ROOT") or r"D:\QMT\data\minute_history")


def _history_database_url(request: HistoryMinuteSyncRequest) -> str:
    return str(request.database_url or os.getenv("QMT_MINUTE_DATABASE_URL") or os.getenv("DATABASE_URL") or "").strip()


def _update_history_job(job_id: str, **updates: Any) -> None:
    with _HISTORY_JOBS_LOCK:
        job = _HISTORY_JOBS.setdefault(job_id, {})
        job.update(updates)
        job["updated_at"] = _now_iso()


def _append_history_log(job_id: str, line: str) -> None:
    with _HISTORY_JOBS_LOCK:
        job = _HISTORY_JOBS.setdefault(job_id, {})
        logs = list(job.get("logs") or [])
        logs.append(line)
        job["logs"] = logs[-200:]
        job["updated_at"] = _now_iso()


def _handle_history_progress_line(job_id: str, line: str) -> None:
    universe_match = re.search(r"universe=(\d+)", line)
    windows_match = re.search(r"windows=(\d+)", line)
    symbol_match = re.search(r"\((\d+)/(\d+)\)\s+symbol=([A-Z0-9.]+)", line)
    if universe_match:
        total = int(universe_match.group(1))
        _update_history_job(job_id, progress=12, message=f"已解析股票池，共 {total} 只股票", universe=total)
        return
    if windows_match:
        total = int(windows_match.group(1))
        _update_history_job(job_id, progress=16, message=f"已拆分下载窗口，共 {total} 个时间窗口", windows=total)
        return
    if symbol_match:
        current = int(symbol_match.group(1))
        total = int(symbol_match.group(2))
        symbol = symbol_match.group(3)
        progress = min(88, 20 + int((current / max(total, 1)) * 68))
        _update_history_job(
            job_id,
            progress=progress,
            message=f"QMT 正在处理第 {current}/{total} 只股票：{symbol}",
            current_symbol=symbol,
            current_symbol_index=current,
            total_symbols=total,
        )
        return
    if "retry symbol=" in line:
        _update_history_job(job_id, progress=30, message=line.replace("[qmt-minute-sync] ", ""))


def _run_history_minute_job(job_id: str, request: HistoryMinuteSyncRequest) -> None:
    script_path = _history_script_path()
    if not script_path.exists():
        _update_history_job(job_id, status="failed", progress=0, message=f"脚本不存在：{script_path}", error=f"script not found: {script_path}", finished_at=_now_iso())
        return

    database_url = _history_database_url(request)
    if request.import_db and not database_url:
        _update_history_job(job_id, status="failed", progress=0, message="缺少 QMT_MINUTE_DATABASE_URL / DATABASE_URL，无法导入数据库", error="database_url is required", finished_at=_now_iso())
        return

    command = [
        sys.executable,
        str(script_path),
        "--period",
        request.period,
        "--start-date",
        request.start_date,
        "--end-date",
        request.end_date,
        "--output-root",
        _history_output_root(request),
        "--format",
        request.file_format,
        "--window-days",
        str(request.window_days),
        "--retry-times",
        str(request.retry_times),
        "--retry-sleep",
        str(request.retry_sleep),
    ]
    if request.symbols:
        command.extend(["--symbols", *request.symbols])
    else:
        command.extend(["--sector", request.sector])
    if request.import_db:
        command.extend(["--import-db", "--database-url", database_url])
    if request.force:
        command.append("--force")

    _update_history_job(job_id, status="running", progress=10, message="已启动 QMT 历史分钟线脚本，正在解析股票池", command=command, started_at=_now_iso())
    try:
        process = subprocess.Popen(
            command,
            cwd=str(Path(__file__).resolve().parents[1]),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="ignore",
        )
        assert process.stdout is not None
        assert process.stderr is not None
        for line in process.stdout:
            line = line.strip()
            if not line:
                continue
            _append_history_log(job_id, line)
            _handle_history_progress_line(job_id, line)
        stderr_text = process.stderr.read().strip()
        if stderr_text:
            _append_history_log(job_id, stderr_text)
        returncode = process.wait()
        if returncode != 0:
            message = stderr_text or f"QMT 历史分钟线脚本失败，exit_code={returncode}"
            _update_history_job(job_id, status="failed", progress=0, message=message[:500], error=message, finished_at=_now_iso())
            return
        rows_total = 0
        logs = _HISTORY_JOBS.get(job_id, {}).get("logs") or []
        for item in reversed(logs):
            try:
                payload = json.loads(item)
            except Exception:
                continue
            if isinstance(payload, dict) and payload.get("type") == "run_finished":
                rows_total = int(payload.get("imported_rows_total") or payload.get("rows_total") or 0)
                break
        _update_history_job(job_id, status="completed", progress=100, message=f"QMT 分钟线同步完成，导入/生成记录约 {rows_total} 条", rows_total=rows_total, finished_at=_now_iso())
    except Exception as exc:
        _update_history_job(job_id, status="failed", progress=0, message=f"QMT 历史分钟线任务异常：{exc}", error=str(exc), finished_at=_now_iso())


@app.get("/health")
def health(authorization: str | None = Header(default=None)):
    _require_token(authorization)
    return {
        "status": "ok",
        "bridge": "qmt",
        "role": _bridge_role(),
        "trading_allowed": _bridge_trading_allowed(),
        "userdata_path": str(os.getenv("QMT_USERDATA_PATH") or ""),
    }


@app.get("/snapshot")
def snapshot(
    account_id: str = Query(...),
    account_type: str = Query("STOCK"),
    account_key: str | None = Query(default=None),
    authorization: str | None = Header(default=None),
):
    _require_token(authorization)
    payload = _query_snapshot(account_id, account_type)
    payload["bridge"] = {
        "mode": "http_bridge",
        "account_key": account_key,
        "account_id": account_id,
        "role": _bridge_role(),
        "trading_allowed": _bridge_trading_allowed(),
    }
    return payload


@app.post("/orders")
def submit_order(body: OrderSubmitRequest, authorization: str | None = Header(default=None)):
    _require_token(authorization)
    _require_trading_allowed("submit_order", body.account_key)
    payload = _submit_order(body)
    payload["bridge"] = {
        "mode": "http_bridge",
        "account_key": body.account_key,
        "account_id": body.account_id,
        "role": _bridge_role(),
        "trading_allowed": _bridge_trading_allowed(),
    }
    return payload


@app.post("/orders/{order_id}/cancel")
def cancel_order(
    order_id: str,
    account_id: str = Query(...),
    account_type: str = Query("STOCK"),
    account_key: str | None = Query(default=None),
    authorization: str | None = Header(default=None),
):
    _require_token(authorization)
    _require_trading_allowed("cancel_order", account_key)
    payload = _cancel_order(account_id, account_type, order_id)
    payload["bridge"] = {
        "mode": "http_bridge",
        "account_key": account_key,
        "account_id": account_id,
        "role": _bridge_role(),
        "trading_allowed": _bridge_trading_allowed(),
    }
    return payload


@app.post("/history/minute/sync")
def start_history_minute_sync(body: HistoryMinuteSyncRequest, authorization: str | None = Header(default=None)):
    _require_token(authorization)
    job_id = uuid4().hex
    now = _now_iso()
    with _HISTORY_JOBS_LOCK:
        _HISTORY_JOBS[job_id] = {
            "job_id": job_id,
            "status": "pending",
            "progress": 0,
            "message": "任务已创建",
            "request": body.model_dump(),
            "logs": [],
            "created_at": now,
            "updated_at": now,
        }
    thread = threading.Thread(target=_run_history_minute_job, args=(job_id, body), daemon=True)
    thread.start()
    return _HISTORY_JOBS[job_id]


@app.get("/history/minute/jobs/{job_id}")
def get_history_minute_job(job_id: str, authorization: str | None = Header(default=None)):
    _require_token(authorization)
    with _HISTORY_JOBS_LOCK:
        job = _HISTORY_JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="history minute job not found")
        return dict(job)


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("QMT_BRIDGE_HOST", "0.0.0.0")
    port = int(os.getenv("QMT_BRIDGE_PORT", "8710"))
    uvicorn.run(app, host=host, port=port, reload=False)
